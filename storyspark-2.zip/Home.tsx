/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/* tslint:disable */
import {
  GoogleGenAI,
  Modality,
  Type,
} from '@google/genai';
import {
  BookOpen,
  ChevronLeft,
  ChevronRight,
  Download,
  Eraser,
  LoaderCircle,
  PaintBucket,
  Paintbrush,
  Pause,
  Pencil,
  Play,
  Redo2,
  Send,
  Trash2,
  Undo2,
} from 'lucide-react';
// Fix: Import MouseEvent to resolve React namespace errors.
import {useCallback, useEffect, useMemo, useRef, useState, MouseEvent} from 'react';

// --- Audio Decoding Utilities ---
// These functions are used to process the raw audio data from the Gemini API.

/**
 * Decodes a base64 string into a Uint8Array.
 * This is necessary because the API returns audio data in base64 format.
 */
function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

/**
 * Decodes raw PCM audio data into an AudioBuffer that can be played by the browser.
 * @param data The raw audio data as a Uint8Array.
 * @param ctx The AudioContext to use for creating the buffer.
 * @param sampleRate The sample rate of the audio (Gemini TTS uses 24000).
 * @param numChannels The number of audio channels (mono = 1).
 * @returns A promise that resolves to an AudioBuffer.
 */
async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  // The raw data is 16-bit PCM, so we create a Int16Array view on the buffer.
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      // Normalize the 16-bit integer samples to the -1.0 to 1.0 range for the Web Audio API.
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const ai = new GoogleGenAI({apiKey: process.env.API_KEY});

const VOICES = [
  {id: 'Zephyr', name: 'Friendly Narrator'},
  {id: 'Puck', name: 'Playful Storyteller'},
  {id: 'Kore', name: 'Gentle Narrator'},
  {id: 'Charon', name: 'Deep Storyteller'},
  {id: 'Fenrir', name: 'Bold Narrator'},
];

const THEMES = [
  'Adventure',
  'Animals',
  'Bedtime',
  'Be Yourself!',
  'Bravery',
  'Cultural Diversity',
  'Dance',
  'Family',
  'Fantasy',
  'Friendship',
  'Identity',
  'Kindness & Empathy',
  'LGBTQ+ Pride',
  'Magic',
  'Mystery',
  'Romance',
  'School',
  'Science',
  'Sci-Fi',
  'Space',
  'Sports',
  'Superheroes',
  'Video Games',
];

const COLORS = [
  '#ef4444', '#f97316', '#eab308', '#22c55e', '#3b82f6', '#8b5cf6',
  '#ec4899', '#a16207', '#65a30d', '#0891b2', '#4338ca', '#be185d',
  '#f8fafc', '#64748b', '#334155', '#1e293b'
];

const BRUSH_SIZES = {
  small: 5,
  medium: 10,
  large: 20,
};

const getStoryConfigForAge = (age: number) => {
  if (age <= 2) {
    return {
      pageRange: '3 to 5 pages',
      promptDetails:
        'one or two very simple sentences per page, focusing on basic concepts and repetition',
    };
  }
  if (age <= 5) {
    return {
      pageRange: '5 to 7 pages',
      promptDetails: 'simple sentences and a low word count per page',
    };
  }
  if (age <= 8) {
    return {
      pageRange: '6 to 8 pages',
      promptDetails: 'simple paragraphs and a moderate word count per page',
    };
  }
  if (age <= 12) {
    return {
      pageRange: '7 to 10 pages',
      promptDetails: 'slightly more complex sentences and paragraphs',
    };
  }
  return {
    pageRange: '9 to 12 pages',
    promptDetails:
      'more complex sentences, developed paragraphs, and a higher word count per page',
  };
};

const getFunFactCountForAge = (age: number): string => {
  if (age <= 2) return '1 to 2';
  if (age <= 5) return 'between 2 to 3';
  if (age <= 8) return 'between 3 to 4';
  if (age <= 12) return 'between 4 to 5';
  return 'between 5 to 6';
};

const getFontSizeForAge = (age: number): string => {
  if (age <= 2) return '2.5rem';
  if (age <= 5) return '2.0rem';
  if (age <= 8) return '1.6rem';
  if (age <= 12) return '1.2rem';
  return '1rem';
};

// Custom Book Stack Icon Component
const BookStackIcon = ({className}: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    className={className}
    aria-hidden="true"
  >
    {/* Book 1 (Bottom, Green) */}
    <polygon fill="#dcfce7" points="21,20 12,22 3,20 3,16 12,14 21,16" />
    <polygon fill="#22c55e" points="12,14 21,16 12,18 3,16" />

    {/* Book 2 (Middle, Blue) */}
    <polygon fill="#dbeafe" points="21,15 12,17 3,15 3,11 12,9 21,11" />
    <polygon fill="#3b82f6" points="12,9 21,11 12,13 3,11" />

    {/* Book 3 (Top, Red) */}
    <polygon fill="#fee2e2" points="21,10 12,12 3,10 3,6 12,4 21,6" />
    <polygon fill="#ef4444" points="12,4 21,6 12,8 3,6" />
  </svg>
);


// Main Home Component
export default function Home() {
  // --- State Management ---
  const [age, setAge] = useState<string>('5');
  const [selectedThemes, setSelectedThemes] = useState<string[]>([]);
  const [prompt, setPrompt] = useState<string>('');
  const [isColoringBook, setIsColoringBook] = useState<boolean>(false);
  const [voice, setVoice] = useState<string>(VOICES[0].id);
  const [story, setStory] = useState<{ title: string; pages: { text: string; image: string }[] } | null>(null);
  const [currentPage, setCurrentPage] = useState<number>(0);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingMessage, setLoadingMessage] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState<number>(0);

  // Narration state
  const [isNarrationPlaying, setIsNarrationPlaying] = useState<boolean>(false);
  const [isNarratingLoading, setIsNarratingLoading] = useState<boolean>(false);
  const [currentAudio, setCurrentAudio] = useState<AudioBufferSourceNode | null>(null);
  const [highlightedWordIndex, setHighlightedWordIndex] = useState<number | null>(null);
  const [narrationSpeed, setNarrationSpeed] = useState<number>(1);
  const audioContextRef = useRef<AudioContext | null>(null);
  // Fix: Use ReturnType<typeof setTimeout> for browser compatibility instead of NodeJS.Timeout.
  const highlightTimeoutsRef = useRef<ReturnType<typeof setTimeout>[]>([]);

  // Coloring book state
  const [activeTool, setActiveTool] = useState<'brush' | 'eraser' | 'fill'>('brush');
  const [brushSize, setBrushSize] = useState<number>(BRUSH_SIZES.medium);
  const [selectedColor, setSelectedColor] = useState<string>(COLORS[0]);
  const [pageCanvasData, setPageCanvasData] = useState<{ [key: number]: string }>({});
  const [history, setHistory] = useState<{ [key: number]: string[] }>({});
  const [historyIndex, setHistoryIndex] = useState<{ [key: number]: number }>({});

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const imageRef = useRef<HTMLImageElement | null>(null);
  const isDrawing = useRef<boolean>(false);
  const lastPos = useRef<{ x: number, y: number } | null>(null);


  // --- Effects ---
  useEffect(() => {
    // Initialize the Web Audio API context.
    // This is done in an effect to ensure it runs only on the client side.
    // Fix: Cast window to any to access webkitAudioContext for older browser compatibility.
    audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({sampleRate: 24000});
  }, []);

  // Cleanup audio on component unmount
  useEffect(() => {
    return () => {
      if (currentAudio) {
        currentAudio.stop();
      }
      highlightTimeoutsRef.current.forEach(clearTimeout);
      audioContextRef.current?.close();
    };
  }, [currentAudio]);

  // Handle canvas resize
  const loadCanvasState = useCallback(() => {
    if (canvasRef.current && isColoringBook) {
        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        const dataUrl = pageCanvasData[currentPage];
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        if (dataUrl) {
            const img = new Image();
            img.onload = () => {
                ctx.drawImage(img, 0, 0);
            };
            img.src = dataUrl;
        }
    }
  }, [currentPage, pageCanvasData, isColoringBook]);


  useEffect(() => {
    const image = imageRef.current;
    const canvas = canvasRef.current;

    const handleResize = () => {
        if (image && canvas) {
            canvas.width = image.clientWidth;
            canvas.height = image.clientHeight;
            loadCanvasState();
        }
    };

    if (image && isColoringBook) {
        // Initial resize on image load
        image.onload = handleResize;
        // If image is already loaded (e.g., from cache)
        if (image.complete) {
            handleResize();
        }
        
        const resizeObserver = new ResizeObserver(handleResize);
        resizeObserver.observe(image);

        return () => {
            resizeObserver.disconnect();
            image.onload = null;
        }
    }
}, [story, currentPage, isColoringBook, loadCanvasState]);

  // Initialize history for a new page
  useEffect(() => {
    if (isColoringBook && !history[currentPage] && canvasRef.current) {
        const canvas = canvasRef.current;
        // Create an empty initial state
        const initialDataUrl = canvas.toDataURL();
        setHistory(prev => ({...prev, [currentPage]: [initialDataUrl]}));
        setHistoryIndex(prev => ({...prev, [currentPage]: 0}));
    }
  }, [currentPage, isColoringBook, history, story]);

  // --- Narration Logic ---
  const cleanupHighlighting = () => {
    highlightTimeoutsRef.current.forEach(clearTimeout);
    highlightTimeoutsRef.current = [];
    setHighlightedWordIndex(null);
  };

  const stopNarration = () => {
    if (currentAudio) {
      currentAudio.onended = null;
      currentAudio.stop();
    }
    cleanupHighlighting();
    setIsNarrationPlaying(false);
    setCurrentAudio(null);
  };

  const handleSpeedChange = () => {
    if (isNarrationPlaying) {
      stopNarration();
    }
    setNarrationSpeed(prev => {
      const speeds = [0.75, 1, 1.25, 1.5];
      const currentIndex = speeds.indexOf(prev);
      const nextIndex = (currentIndex + 1) % speeds.length;
      return speeds[nextIndex];
    });
  };

  const toggleNarration = async () => {
    if (isNarrationPlaying) {
      stopNarration();
      return;
    }
    if (!story || !audioContextRef.current) return;

    setIsNarratingLoading(true);
    setIsNarrationPlaying(true);
    setHighlightedWordIndex(null); // Reset highlight
    const pageText = story.pages[currentPage].text;

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-preview-tts',
        contents: [{parts: [{text: pageText}]}],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {prebuiltVoiceConfig: {voiceName: voice}},
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (!base64Audio) {
        throw new Error('No audio data received from API.');
      }

      const audioBytes = decode(base64Audio);
      const audioBuffer = await decodeAudioData(
        audioBytes,
        audioContextRef.current,
        24000,
        1,
      );

      // --- Highlighting Logic (heuristic adjusted for speed) ---
      const words = pageText.split(/\s+/).filter(w => w.length > 0);
      const totalChars = words.join('').length;
      const actualDuration = audioBuffer.duration / narrationSpeed; // Adjust duration based on speed

      if (totalChars > 0 && actualDuration > 0) {
        const timePerChar = actualDuration / totalChars;
        let cumulativeDelay = 0;

        words.forEach((word, index) => {
          // Estimate word duration and scale the small buffer time as well
          const wordDuration = (word.length * timePerChar) + (0.05 / narrationSpeed);
          const timeoutId = setTimeout(() => {
            setHighlightedWordIndex(index);
          }, cumulativeDelay * 1000);
          highlightTimeoutsRef.current.push(timeoutId);
          cumulativeDelay += wordDuration;
        });
      }

      const source = audioContextRef.current.createBufferSource();
      source.buffer = audioBuffer;
      source.playbackRate.value = narrationSpeed; // Set the playback speed
      source.connect(audioContextRef.current.destination);
      source.onended = () => {
        cleanupHighlighting();
        setIsNarrationPlaying(false);
        setCurrentAudio(null);
      };
      source.start();
      setCurrentAudio(source);
    } catch (e) {
      console.error('Narration failed:', e);
      setError('Sorry, the narrator is taking a break. Please try again.');
      stopNarration();
    } finally {
      setIsNarratingLoading(false);
    }
  };


  // --- Core Story Generation Logic ---
  const generateStory = async () => {
    if (!prompt) {
      setError('Please tell me what the story should be about!');
      return;
    }
    if (selectedThemes.length === 0) {
      setError('Please choose at least one theme!');
      return;
    }
    setIsLoading(true);
    setLoadingMessage('Dreaming up a new adventure...');
    setError(null);
    setStory(null);
    setCurrentPage(0);
    setPageCanvasData({}); // Clear old drawings
    setProgress(2); // Start with a small progress value

    try {
      const numericAge = parseInt(age) || 5;
      const storyConfig = getStoryConfigForAge(numericAge);
      const funFactCount = getFunFactCountForAge(numericAge);

      const storyPrompt = `Create a children's story for a ${numericAge}-year-old.
Theme(s): ${selectedThemes.join(', ')}.
The story should be about: "${prompt}".
The story should be between ${storyConfig.pageRange}, with ${storyConfig.promptDetails}.
Include ${funFactCount} fun facts related to the story's theme or characters.
The story should have a positive and uplifting message.
It's very important that the story is engaging and easy for a child of this age to understand.
Make sure the story is well-structured with a beginning, middle, and end.
Generate a unique and creative title for the story.
Each page should have a corresponding image.
The final page should say "The End".
When a book is created ENSURE THE CHARACTERS STAY THE SAME. MAKE SURE ALL BODY PARTS ARE IN EACH PAGE. WHEN NEW CHARACTERS ARE ADDED- INTRODUCE THEM.
MAKE SURE ALL CHARACTERS look the same. all animals have the same body parts & patterns. All heroes and humans have the same body features, and make sure the drawings match the story line For each story.
Integrate the fun facts seamlessly into the narrative. They should appear at different, natural points in the story, not clustered together. Introduce these facts using conversational phrases like "Did you know...", "Here's a cool secret:", "Guess what!", or other rephrases of that, instead of the static "Fun Fact:".
${isColoringBook ? 'The illustrations should be black and white line art, suitable for a coloring book.' : 'The illustrations should be in a whimsical, colorful, and child-friendly art style.'}
`;

      setLoadingMessage('Writing the first chapter...');
      setProgress(10);
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: [{parts: [{text: storyPrompt}]}],
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: {type: Type.STRING},
              pages: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    text: {type: Type.STRING},
                  },
                  required: ['text'],
                },
              },
            },
            required: ['title', 'pages'],
          },
        },
      });

      const storyData = JSON.parse(response.text);
      const numPages = storyData.pages.length;
      const textGenerationProgress = 20; // Assign 20% for text generation
      setProgress(textGenerationProgress);


      const pagesWithImages = [];
      const imageGenerationTotalProgress = 100 - textGenerationProgress;

      for (let index = 0; index < numPages; index++) {
        const page = storyData.pages[index];
        setLoadingMessage(`Illustrating page ${index + 1} of ${numPages}...`);
        const imageStyle = isColoringBook
          ? 'black and white line art, coloring book style, clean lines, no shading'
          : 'whimsical, colorful, child-friendly';
        const imagePromptText = `Illustration for a children's book page with the text: "${page.text}". The story is about "${prompt}". Maintain character consistency. Style: ${imageStyle}.`;

        const imageResponse = await ai.models.generateContent({
          model: 'gemini-2.5-flash-image',
          contents: {
            parts: [{text: imagePromptText}],
          },
          config: {
            responseModalities: [Modality.IMAGE],
          },
        });
        let image = '';
        for (const part of imageResponse.candidates[0].content.parts) {
          if (part.inlineData) {
            const base64ImageBytes: string = part.inlineData.data;
            image = `data:image/png;base64,${base64ImageBytes}`;
          }
        }
        pagesWithImages.push({text: page.text, image});
        
        // Update progress after each image is generated
        const progressPerImage = imageGenerationTotalProgress / numPages;
        setProgress(p => p + progressPerImage);
      }

      setStory({title: storyData.title, pages: pagesWithImages});
    } catch (e) {
      console.error(e);
      setError('Oh no! Something went wrong while creating your story. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };
  
  // --- Coloring Book Logic ---
  const pushToHistory = useCallback(() => {
    if (!canvasRef.current || !isColoringBook) return;
    const canvas = canvasRef.current;
    const dataUrl = canvas.toDataURL();
    const currentHistory = history[currentPage] || [];
    const currentIndex = historyIndex[currentPage] ?? -1;

    // If we undo and then draw, we erase the "redo" history
    const newHistory = currentHistory.slice(0, currentIndex + 1);
    newHistory.push(dataUrl);

    setHistory(prev => ({ ...prev, [currentPage]: newHistory }));
    setHistoryIndex(prev => ({ ...prev, [currentPage]: newHistory.length - 1 }));
  }, [currentPage, history, historyIndex, isColoringBook]);

  const handleUndo = () => {
    const currentIndex = historyIndex[currentPage];
    if (currentIndex > 0) {
      const newIndex = currentIndex - 1;
      setHistoryIndex(prev => ({...prev, [currentPage]: newIndex}));
      const dataUrl = history[currentPage][newIndex];
      const img = new Image();
      const canvas = canvasRef.current;
      const ctx = canvas?.getContext('2d');
      if (!ctx || !canvas) return;
      img.onload = () => {
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(img, 0, 0);
      };
      img.src = dataUrl;
    }
  };

  const handleRedo = () => {
    const currentIndex = historyIndex[currentPage];
    const currentHistory = history[currentPage] || [];
    if (currentIndex < currentHistory.length - 1) {
      const newIndex = currentIndex + 1;
      setHistoryIndex(prev => ({...prev, [currentPage]: newIndex}));
      const dataUrl = history[currentPage][newIndex];
      const img = new Image();
      const canvas = canvasRef.current;
      const ctx = canvas?.getContext('2d');
      if (!ctx || !canvas) return;
      img.onload = () => {
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(img, 0, 0);
      };
      img.src = dataUrl;
    }
  };
  
  const handleClearPage = () => {
    if (canvasRef.current) {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      ctx?.clearRect(0, 0, canvas.width, canvas.height);
      pushToHistory();
    }
  };

  const handleDownload = () => {
    const canvas = canvasRef.current;
    const image = imageRef.current;
    if (!canvas || !image || !story) return;

    const downloadCanvas = document.createElement('canvas');
    downloadCanvas.width = image.naturalWidth;
    downloadCanvas.height = image.naturalHeight;
    const ctx = downloadCanvas.getContext('2d');
    if (!ctx) return;

    // Draw background image first
    ctx.drawImage(image, 0, 0, image.naturalWidth, image.naturalHeight);
    // Draw user's coloring on top, scaling it to the natural image size
    ctx.drawImage(canvas, 0, 0, image.naturalWidth, image.naturalHeight);
    
    const link = document.createElement('a');
    link.download = `${story.title.replace(/\s/g, '_')}_page_${currentPage + 1}.png`;
    link.href = downloadCanvas.toDataURL();
    link.click();
  }

  // Fix: Use MouseEvent<HTMLCanvasElement> type from react import
  const getMousePos = (e: MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    return {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    };
  };

  const draw = (start: {x:number, y:number}, end: {x:number, y:number}) => {
    const ctx = canvasRef.current?.getContext('2d');
    if (!ctx) return;
    
    ctx.beginPath();
    ctx.moveTo(start.x, start.y);
    ctx.lineTo(end.x, end.y);
    ctx.strokeStyle = selectedColor;
    ctx.lineWidth = brushSize;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.globalCompositeOperation = activeTool === 'eraser' ? 'destination-out' : 'source-over';
    ctx.stroke();
  };

  // Fix: Use MouseEvent<HTMLCanvasElement> type from react import
  const handleMouseDown = (e: MouseEvent<HTMLCanvasElement>) => {
    if (activeTool === 'fill') return;
    isDrawing.current = true;
    lastPos.current = getMousePos(e);
  };
  
  // Fix: Use MouseEvent<HTMLCanvasElement> type from react import
  const handleMouseMove = (e: MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing.current || activeTool === 'fill') return;
    const currentPos = getMousePos(e);
    if(lastPos.current) {
      draw(lastPos.current, currentPos);
      lastPos.current = currentPos;
    }
  };

  const handleMouseUp = () => {
    if (activeTool === 'fill') return;
    isDrawing.current = false;
    lastPos.current = null;
    pushToHistory();
  };
  
  // Fix: Use MouseEvent<HTMLCanvasElement> type from react import
  const handleCanvasClick = (e: MouseEvent<HTMLCanvasElement>) => {
    if (activeTool !== 'fill') return;
    const {x, y} = getMousePos(e);
    floodFill(Math.round(x), Math.round(y));
    pushToHistory();
  };
  
  const floodFill = (startX: number, startY: number) => {
    const canvas = canvasRef.current;
    const image = imageRef.current;
    if (!canvas || !image) return;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;
  
    const offscreenCanvas = document.createElement('canvas');
    offscreenCanvas.width = canvas.width;
    offscreenCanvas.height = canvas.height;
    const offscreenCtx = offscreenCanvas.getContext('2d', { willReadFrequently: true });
    if (!offscreenCtx) return;
  
    offscreenCtx.drawImage(image, 0, 0, canvas.width, canvas.height);
    const sourceData = offscreenCtx.getImageData(0, 0, canvas.width, canvas.height).data;
    
    const startPos = (startY * canvas.width + startX) * 4;
    // Boundary is black, so if source pixel is not white-ish, don't fill.
    if (sourceData[startPos] < 200) return;
  
    const destImageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const destData = destImageData.data;
  
    const hex = selectedColor.replace('#', '');
    const fillR = parseInt(hex.substring(0, 2), 16);
    const fillG = parseInt(hex.substring(2, 4), 16);
    const fillB = parseInt(hex.substring(4, 6), 16);
  
    const queue = [[startX, startY]];
    const visited = new Set([`${startX},${startY}`]);
  
    while (queue.length > 0) {
      const [x, y] = queue.shift()!;
  
      const currentPos = (y * canvas.width + x) * 4;
      
      // Color the pixel
      destData[currentPos] = fillR;
      destData[currentPos + 1] = fillG;
      destData[currentPos + 2] = fillB;
      destData[currentPos + 3] = 255;
  
      const neighbors = [[x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]];
      for (const [nx, ny] of neighbors) {
        if (nx >= 0 && nx < canvas.width && ny >= 0 && ny < canvas.height && !visited.has(`${nx},${ny}`)) {
          visited.add(`${nx},${ny}`);
          const neighborPos = (ny * canvas.width + nx) * 4;
          // Check source image for boundary and if destination is already colored
          if (sourceData[neighborPos] > 200 && destData[neighborPos + 3] === 0) {
            queue.push([nx, ny]);
          }
        }
      }
    }
  
    ctx.putImageData(destImageData, 0, 0);
  };
  
  // --- Story Viewer Page Navigation ---
   const saveCanvasState = () => {
    if (!canvasRef.current || !isColoringBook) return;
    const dataUrl = canvasRef.current.toDataURL();
    setPageCanvasData(prev => ({...prev, [currentPage]: dataUrl}));
  };

  const handleNextPage = () => {
    saveCanvasState();
    stopNarration();
    setCurrentPage(p => Math.min(story!.pages.length - 1, p + 1));
  };

  const handlePrevPage = () => {
    saveCanvasState();
    stopNarration();
    setCurrentPage(p => Math.max(0, p - 1));
  };

  const handleBackToEditor = () => {
    saveCanvasState();
    stopNarration();
    setStory(null);
    setCurrentPage(0);
  };
  
  const ColoringTools = () => {
    const isUndoable = (historyIndex[currentPage] ?? 0) > 0;
    const isRedoable = (historyIndex[currentPage] ?? -1) < (history[currentPage]?.length ?? 0) - 1;

    return (
      <div className="absolute -left-2 top-1/2 -translate-x-full -translate-y-1/2 h-fit p-3 bg-white/80 backdrop-blur-sm flex flex-col items-center gap-4 rounded-lg shadow-lg border">
          <div className="flex flex-col gap-2" role="radiogroup" aria-labelledby="tool-label">
              <span id="tool-label" className="font-bold text-sm text-gray-600 self-center">Tool</span>
              <button onClick={() => setActiveTool('brush')} title="Brush" aria-label="Brush" className={`p-2 rounded-lg ${activeTool === 'brush' ? 'bg-orange-400 text-white' : 'bg-gray-200 hover:bg-gray-300'}`}><Paintbrush size={24} /></button>
              <button onClick={() => setActiveTool('fill')} title="Fill" aria-label="Fill" className={`p-2 rounded-lg ${activeTool === 'fill' ? 'bg-orange-400 text-white' : 'bg-gray-200 hover:bg-gray-300'}`}><PaintBucket size={24} /></button>
              <button onClick={() => setActiveTool('eraser')} title="Eraser" aria-label="Eraser" className={`p-2 rounded-lg ${activeTool === 'eraser' ? 'bg-orange-400 text-white' : 'bg-gray-200 hover:bg-gray-300'}`}><Eraser size={24} /></button>
          </div>
          <div className="w-full h-px bg-gray-300"></div>
          <div className="flex flex-col gap-2" role="radiogroup" aria-labelledby="size-label">
              <span id="size-label" className="font-bold text-sm text-gray-600 self-center">Size</span>
              {Object.entries(BRUSH_SIZES).map(([name, size]) => (
                <button key={name} onClick={() => setBrushSize(size)} className={`w-10 h-10 rounded-full flex items-center justify-center transition-transform hover:scale-110 ${brushSize === size ? 'bg-orange-400' : 'bg-gray-200'}`}>
                    <div className="bg-gray-800 rounded-full" style={{width: `${size*1.5}px`, height: `${size*1.5}px`}}></div>
                </button>
              ))}
          </div>
          <div className="w-full h-px bg-gray-300"></div>
           <div className="grid grid-cols-4 gap-1.5" role="radiogroup" aria-labelledby="color-label">
               <span id="color-label" className="col-span-4 font-bold text-sm text-gray-600 text-center">Color</span>
               {COLORS.map(color => (
                <button key={color} onClick={() => setSelectedColor(color)} className={`w-7 h-7 rounded-full border-2 transition-transform hover:scale-110 ${selectedColor === color ? 'border-orange-500 scale-110' : 'border-transparent'}`} style={{backgroundColor: color}} aria-label={`Color ${color}`}></button>
               ))}
           </div>
           <div className="w-full h-px bg-gray-300"></div>
           <div className="flex flex-col gap-2 items-center">
              <div className="flex gap-2">
                <button onClick={handleUndo} disabled={!isUndoable} title="Undo" aria-label="Undo" className="p-2 rounded-lg bg-gray-200 hover:bg-gray-300 disabled:opacity-50 disabled:cursor-not-allowed"><Undo2 size={20}/></button>
                <button onClick={handleRedo} disabled={!isRedoable} title="Redo" aria-label="Redo" className="p-2 rounded-lg bg-gray-200 hover:bg-gray-300 disabled:opacity-50 disabled:cursor-not-allowed"><Redo2 size={20}/></button>
              </div>
              <button onClick={handleClearPage} title="Clear Page" aria-label="Clear Page" className="p-2 rounded-lg bg-gray-200 hover:bg-gray-300"><Trash2 size={20}/></button>
              <button onClick={handleDownload} title="Download" aria-label="Download" className="p-2 rounded-lg bg-gray-200 hover:bg-gray-300"><Download size={20}/></button>
           </div>
      </div>
    );
  };
  
  // --- Render Logic ---
  return (
    <div className="min-h-screen bg-orange-50 children-friendly-bg text-gray-800">
      <main className="container mx-auto px-4 py-8 relative">
        {/* "My Library" Button */}
        <div className="absolute top-4 right-4 sm:top-8 sm:right-8 z-10">
            <button className="inline-flex items-center gap-3 px-8 py-3 bg-white/80 backdrop-blur-sm text-lg font-bold text-gray-700 rounded-full shadow-md hover:bg-white transition-colors">
                <BookOpen className="text-red-500" size={24} />
                <span>My Library</span>
            </button>
        </div>

        {/* Header */}
        <header className="text-center mb-8">
          <h1 className="text-6xl md:text-8xl font-bold font-title text-orange-500 flex items-center justify-center gap-4">
            <span>StorySpark</span>
            <BookStackIcon className="w-16 h-16 md:w-24 md:h-24" />
          </h1>
          <p className="text-lg text-gray-600 mt-2">
            Where you can make your <span className="font-bold">imagination</span> go wild!
          </p>
        </header>

        {/* Story Creation Form */}
        <div className="max-w-3xl mx-auto book-form-container p-8 sm:p-12">
          <h2 className="text-center text-3xl font-bold text-gray-800 mb-6">Let's create a story!</h2>

          {/* Age Selector */}
          <div className="mb-6">
            <label
              htmlFor="age"
              className="block text-xl font-bold text-gray-700 mb-2"
            >
              Who is this story for? (Enter age)
            </label>
            <input
                type="text"
                id="age"
                value={age}
                onChange={(e) => setAge(e.target.value)}
                className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:border-transparent transition"
                placeholder="E.g., 5"
                aria-label="Reader's age"
              />
          </div>

          {/* Theme Selector */}
          <div className="mb-6">
            <label className="block text-xl font-bold text-gray-700 mb-3">
              Choose themes
            </label>
            <div className="flex gap-2 mb-3">
              <button onClick={() => setSelectedThemes(THEMES)} className="px-3 py-1 text-sm font-semibold bg-orange-200 text-orange-800 rounded-full hover:bg-orange-300 transition-colors">Select All</button>
              <button onClick={() => setSelectedThemes([])} className="px-3 py-1 text-sm font-semibold bg-gray-200 text-gray-800 rounded-full hover:bg-gray-300 transition-colors">Clear All</button>
            </div>
            <div className="flex flex-wrap gap-3">
              {THEMES.map((theme) => (
                <button
                  key={theme}
                  onClick={() => {
                    setSelectedThemes((prev) => {
                      if (prev.includes(theme)) {
                        return prev.filter((t) => t !== theme);
                      }
                      return [...prev, theme];
                    });
                  }}
                  className={`px-4 py-2 text-base font-semibold rounded-full transition-all duration-200 ${
                    selectedThemes.includes(theme)
                      ? 'bg-orange-500 text-white shadow-md scale-105'
                      : 'bg-orange-100 text-orange-800 hover:bg-orange-200'
                  }`}
                >
                  {theme}
                </button>
              ))}
            </div>
          </div>

          {/* Prompt Input */}
          <div className="mb-6">
            <label
              htmlFor="prompt"
              className="block text-xl font-bold text-gray-700 mb-2"
            >
              What should the story be about?
            </label>
            <div className="relative">
              <Pencil
                className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"
                size={20}
              />
              <input
                type="text"
                id="prompt"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="e.g., a brave little dragon who loves to bake"
                className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-full focus:ring-2 focus:ring-orange-400 focus:border-transparent transition"
              />
            </div>
          </div>

          {/* Options */}
          <div className="mb-8">
            <div className="flex flex-wrap items-center gap-6">
              {/* Voice Selector */}
              <div>
                <label htmlFor="voice" className="block text-xl font-bold text-gray-700 mb-2">
                  Narrator's Voice
                </label>
                <select
                  id="voice"
                  value={voice}
                  onChange={(e) => setVoice(e.target.value)}
                  className="px-4 py-2 border border-gray-300 rounded-full focus:ring-2 focus:ring-orange-400"
                >
                  {VOICES.map((v) => (
                    <option key={v.id} value={v.id}>{v.name}</option>
                  ))}
                </select>
              </div>
              {/* Narration Speed */}
              <div>
                <label className="block text-xl font-bold text-gray-700 mb-2">
                  Narration Speed
                </label>
                <button
                  onClick={handleSpeedChange}
                  title="Change narration speed"
                  className="text-base font-bold text-orange-500 w-24 text-center bg-orange-100 rounded-full py-2 hover:bg-orange-200 transition-colors"
                >
                  {narrationSpeed.toFixed(2)}x
                </button>
              </div>
            </div>
            {/* Coloring Book Toggle */}
            <div className="flex items-center gap-3 mt-6">
              <label htmlFor="coloring-book" className="text-lg font-semibold text-gray-700 cursor-pointer">
                Generate a coloring book story (black & white)
              </label>
              <button
                role="switch"
                aria-checked={isColoringBook}
                onClick={() => setIsColoringBook(!isColoringBook)}
                id="coloring-book"
                className={`relative inline-flex items-center h-8 w-16 rounded-full transition-colors duration-300 ease-in-out ${isColoringBook ? 'bg-orange-500' : 'bg-gray-300'}`}
              >
                <span className={`inline-block w-6 h-6 transform bg-white rounded-full transition-transform duration-300 ease-in-out ${isColoringBook ? 'translate-x-9' : 'translate-x-1'}`}/>
              </button>
            </div>
          </div>


          {/* Error Message */}
          {error && <p className="text-red-500 text-center mb-4">{error}</p>}

          {/* Generate Button */}
          <button
            onClick={generateStory}
            disabled={isLoading}
            className="w-full flex justify-center items-center gap-3 bg-gradient-to-r from-orange-400 to-red-500 text-white font-bold text-2xl py-4 px-6 rounded-full hover:scale-105 transform transition-transform duration-200 ease-in-out shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? (
              <>
                <LoaderCircle className="animate-spin flex-shrink-0" size={28} />
                <div className="flex-grow text-left mx-4">
                  <span className="text-xl">{loadingMessage}</span>
                  <div className="w-full bg-white/30 rounded-full h-2.5 mt-1">
                    <div 
                      className="bg-white h-2.5 rounded-full" 
                      style={{ width: `${Math.round(progress)}%`, transition: 'width 0.5s ease-in-out' }}
                    ></div>
                  </div>
                </div>
                <span className="font-mono w-20 text-right text-2xl">{Math.round(progress)}%</span>
              </>
            ) : (
              <>
                <Send size={24} />
                <span>Create My Story!</span>
              </>
            )}
          </button>
        </div>
      </main>

      {/* Loading Overlay */}
      {isLoading && (
        <div className="fixed inset-0 bg-white/50 backdrop-blur-sm z-10 flex items-center justify-center">
          {/* This overlay is active during story generation */}
        </div>
      )}


      {/* Story Viewer */}
      {story && (
        <div className="fixed inset-0 bg-white z-20 flex flex-col p-4 sm:p-6 lg:p-8">
          <div className="flex justify-between items-center mb-4">
            <button
              onClick={handleBackToEditor}
              className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
            >
              <ChevronLeft size={24} />
              <span className="font-bold">Back to Editor</span>
            </button>
            <h2 className="text-2xl sm:text-3xl font-bold text-center font-title text-gray-800 truncate px-4">
              {story.title}
            </h2>
            <div className="w-32"></div> {/* Spacer */}
          </div>
          <div className="flex-grow grid grid-cols-1 lg:grid-cols-2 gap-6 items-center">
            <div className="w-full h-full relative bg-gray-100 rounded-lg shadow-inner overflow-hidden flex items-center justify-center">
               {isColoringBook && <ColoringTools/>}
              {story.pages[currentPage].image ? (
                 <>
                  <img
                    ref={imageRef}
                    src={story.pages[currentPage].image}
                    alt={`Illustration for page ${currentPage + 1}`}
                    className="w-full h-full object-contain"
                    crossOrigin="anonymous" // Important for reading pixel data
                  />
                  {isColoringBook && (
                    <canvas
                      ref={canvasRef}
                      className="absolute top-0 left-0 w-full h-full touch-none"
                      onMouseDown={handleMouseDown}
                      onMouseMove={handleMouseMove}
                      onMouseUp={handleMouseUp}
                      onMouseLeave={handleMouseUp}
                      onClick={handleCanvasClick}
                      />
                  )}
                 </>
              ) : (
                <div className="text-gray-500">Generating image...</div>
              )}
            </div>
            <div className="w-full h-full flex flex-col justify-between p-4 bg-white rounded-lg">
              <div className="story-text-display text-gray-700 leading-relaxed overflow-y-auto flex-grow"
                style={{fontSize: getFontSizeForAge(parseInt(age) || 5), maxHeight: 'calc(100vh - 250px)'}}>
                {story.pages[currentPage].text.split(/\s+/).map((word, index) => (
                  <span
                    key={index}
                    className={highlightedWordIndex === index ? 'highlighted-word' : ''}
                  >
                    {word}{' '}
                  </span>
                ))}
              </div>
              <div className="flex justify-between items-center mt-4 pt-4 border-t">
                <button
                  onClick={handlePrevPage}
                  disabled={currentPage === 0}
                  className="p-2 rounded-full bg-gray-200 hover:bg-gray-300 disabled:opacity-50 disabled:cursor-not-allowed"
                  aria-label="Previous Page"
                >
                  <ChevronLeft size={24} />
                </button>
                <div className="flex items-center gap-4">
                  <button
                    onClick={toggleNarration}
                    disabled={isNarratingLoading}
                    className="p-3 rounded-full bg-yellow-400 hover:bg-yellow-500 text-white shadow-md disabled:opacity-50 disabled:cursor-wait"
                    aria-label={isNarrationPlaying ? 'Pause narration' : 'Pause narration'}
                  >
                    {isNarratingLoading ? <LoaderCircle size={24} className="animate-spin" /> : (isNarrationPlaying ? <Pause size={24} /> : <Play size={24} />)}
                  </button>
                   <button
                    onClick={handleSpeedChange}
                    title="Change narration speed"
                    className="text-base font-bold text-orange-500 w-20 text-center bg-orange-100 rounded-full py-2 hover:bg-orange-200 transition-colors"
                  >
                    {narrationSpeed.toFixed(2)}x
                  </button>
                  <span className="text-gray-600 font-semibold">
                    Page {currentPage + 1} of {story.pages.length}
                  </span>
                </div>
                <button
                  onClick={handleNextPage}
                  disabled={currentPage === story.pages.length - 1}
                  className="p-2 rounded-full bg-gray-200 hover:bg-gray-300 disabled:opacity-50 disabled:cursor-not-allowed"
                  aria-label="Next Page"
                >
                  <ChevronRight size={24} />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
